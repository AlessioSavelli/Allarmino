#ifndef ARDUINO_BEARSSL_CONFIG_H_
#define ARDUINO_BEARSSL_CONFIG_H_

/* Enabling this define allows the usage of ArduinoBearSSL without crypto chip. */
//#define ARDUINO_DISABLE_ECCX08

#endif /* ARDUINO_BEARSSL_CONFIG_H_ */
